package br.ucb.ana.bean;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * Classe de entidade que possui os atributos do aluno
 *
 */
public class TrechoPista implements Serializable {

	private Integer idPista;
	private Integer idTrecho;

	public Integer getIdPista() {
		return idPista;
	}

	public void setIdPista(Integer idPista) {
		this.idPista = idPista;
	}

	public Integer getIdTrecho() {
		return idTrecho;
	}

	public void setIdTrecho(Integer idTrecho) {
		this.idTrecho = idTrecho;
	}

}