package br.ucb.ana.bean;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * Classe de entidade que possui os atributos do aluno
 *
 */
public class Trecho implements Serializable {

	private Integer id;
	private Integer idPista;
	private String nomeTrecho;
	private String aceleraReduz;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIdPista() {
		return idPista;
	}

	public void setIdPista(Integer idPista) {
		this.idPista = idPista;
	}

	public String getNomeTrecho() {
		return nomeTrecho;
	}

	public void setNomeTrecho(String nomeTrecho) {
		this.nomeTrecho = nomeTrecho;
	}

	public String getAceleraReduz() {
		return aceleraReduz;
	}

	public void setAceleraReduz(String aceleraReduz) {
		this.aceleraReduz = aceleraReduz;
	}

}