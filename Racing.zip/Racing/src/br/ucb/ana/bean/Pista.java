package br.ucb.ana.bean;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * Classe de entidade que possui os atributos do aluno
 *
 */
public class Pista implements Serializable {

	private Integer id;
	private String nomePista;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNomePista() {
		return nomePista;
	}

	public void setNomePista(String nomePista) {
		this.nomePista = nomePista;
	}

}