package br.ucb.ana.bean;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import javax.servlet.http.HttpServletResponse;


/**
 * 
 * Classe de entidade que possui os atributos do aluno
 *
 */
public class CarroThread extends Thread implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nomePiloto;
	private List<Trecho> lista;
	private String potencia;
	private HttpServletResponse response;

	public CarroThread(String nomePiloto,HttpServletResponse response,String potencia, 
			List<Trecho> lista) {
		super(nomePiloto);
		this.nomePiloto = nomePiloto;
		this.response = response;
		this.potencia = potencia;
		this.lista = lista;
	}

	public void run() {
		try {
			Integer acelerareduzInteger=0;
			for(Trecho t: lista){
				acelerareduzInteger=+Integer.parseInt(t.getAceleraReduz());
			}
		for (int i = 0; i < 10; i++) {
			try {
				sleep((int) (Math.random() * (1000+(acelerareduzInteger))-Integer.parseInt(this.potencia)));
			} catch (Exception e) {
			}
			;
			response.getWriter().println(nomePiloto);
			System.out.print(getName());
			for (int j = 0; j < i; j++){
				
					response.getWriter().println("--");
					
				
				System.out.print("--");
			}response.getWriter().println("> <br/>");
			System.out.println(">");
		}
		response.getWriter().println("completou a prova. <br/>");
		System.out.println(getName() + " completou a prova.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	

	
}