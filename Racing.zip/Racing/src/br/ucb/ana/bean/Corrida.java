package br.ucb.ana.bean;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * Classe de entidade que possui os atributos do aluno
 *
 */
public class Corrida implements Serializable {

	private Integer id;
	private Integer idPista;
	private Integer idCarro1;
	private Integer idCarro2;
	private String nomeCorrida;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIdPista() {
		return idPista;
	}

	public void setIdPista(Integer idPista) {
		this.idPista = idPista;
	}

	public Integer getIdCarro1() {
		return idCarro1;
	}

	public void setIdCarro1(Integer idCarro1) {
		this.idCarro1 = idCarro1;
	}

	public Integer getIdCarro2() {
		return idCarro2;
	}

	public void setIdCarro2(Integer idCarro2) {
		this.idCarro2 = idCarro2;
	}

	public String getNomeCorrida() {
		return nomeCorrida;
	}

	public void setNomeCorrida(String nomeCorrida) {
		this.nomeCorrida = nomeCorrida;
	}

}